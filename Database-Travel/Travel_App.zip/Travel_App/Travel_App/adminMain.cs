﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Travel_App
{
    public partial class adminMain : Form
    {
        public adminMain()
        {
            InitializeComponent();
        }

        NpgsqlConnection baglanti=new NpgsqlConnection("server=localHost; port=5432; Database=dbseyahatproje; " +
            "user Id=Postgres; password=5847");

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminUsers adminUsers = new adminUsers();
            adminUsers.ShowDialog();
            adminUsers = null;
            this.Show();

        }
    }
}
