﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Travel_App
{
    public partial class menuTrips : Form
    {
        public menuTrips()
        {
            InitializeComponent();
        }

        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=seyahatproje; " +
            "user ID=postgres; password=5847");
        private void menuTrips_Load(object sender, EventArgs e)
        {

        }

    }
}
